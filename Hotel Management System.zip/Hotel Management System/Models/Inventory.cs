﻿using System.ComponentModel.DataAnnotations;

namespace Hotel_Management_System.Models
{
    public class Inventory
    {

        [Key]
        public int Inventory_id { get; set; }

        [Required]
        [StringLength(50)]
        public string Item_name { get; set; }

        [Required]
        public int Quantity { get; set; }

        [Required]
        public decimal Amount { get; set; }
    }
}
