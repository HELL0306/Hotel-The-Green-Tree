﻿
using System.ComponentModel.DataAnnotations;
namespace Hotel_Management_System.Models
{
    public class Room
    {
        [Key]
        public int Room_id { get; set; }
        [Required]
        public string Room_type { get; set; }

        public bool Room_status { get; set; }
        [Required]
        public decimal Room_Charge { get; set; }

        [Required]
        public int RoomNo { get; set; }

    }
}
