﻿using System.ComponentModel.DataAnnotations;

namespace Hotel_Management_System.Models
{
    public class Guest
    {
        [Key]
        public int Guest_id { get; set; }
        [Required]
        [StringLength(50)]
        public string Guest_Name { get; set; }
        [Required]
        [StringLength(150)]
        public string Guest_Email { get; set; }
        [Required]
        public string Guest_Gender { get; set; }
        [Required]
        [StringLength(250)]
        public string Guest_Address { get; set; }
        [Required]
        public int Guest_Contact_num { get; set; }
    }
}
