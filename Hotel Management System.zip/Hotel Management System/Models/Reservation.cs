﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Hotel_Management_System.Models
{
    public class Reservation
    {
        [Key]
        public int Reservation_id { get; set; }
        [Required]
        public int No_of_Adults { get; set; }
        [Required]
        public int No_of_Child { get; set; }
        [Required]
        public DateTime Checkin_date { get; set; }
        [Required]
        public DateTime Checkout_date { get; set; }

        public int Room_id { get; set; }
        [ForeignKey("Room_id")]
        public Room Rooms { get; set; }

        public int Guest_id { get; set; }
        [ForeignKey("Guest_id")]
        public Guest Guests { get; set; }


    }
}
