﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Hotel_Management_System.Migrations
{
    /// <inheritdoc />
    public partial class Hotel : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Guests",
                columns: table => new
                {
                    Guest_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Guest_Name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Guest_Email = table.Column<string>(type: "nvarchar(150)", maxLength: 150, nullable: false),
                    Guest_Gender = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Guest_Address = table.Column<string>(type: "nvarchar(250)", maxLength: 250, nullable: false),
                    Guest_Contact_num = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Guests", x => x.Guest_id);
                });

            migrationBuilder.CreateTable(
                name: "Inventories",
                columns: table => new
                {
                    Inventory_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Item_name = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Quantity = table.Column<int>(type: "int", nullable: false),
                    Amount = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Inventories", x => x.Inventory_id);
                });

            migrationBuilder.CreateTable(
                name: "Rooms",
                columns: table => new
                {
                    Room_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Room_type = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Room_status = table.Column<bool>(type: "bit", nullable: false),
                    Room_Charge = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    RoomNo = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Rooms", x => x.Room_id);
                });

            migrationBuilder.CreateTable(
                name: "Reservations",
                columns: table => new
                {
                    Reservation_id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    No_of_Adults = table.Column<int>(type: "int", nullable: false),
                    No_of_Child = table.Column<int>(type: "int", nullable: false),
                    Checkin_date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Checkout_date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Room_id = table.Column<int>(type: "int", nullable: false),
                    Guest_id = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Reservations", x => x.Reservation_id);
                    table.ForeignKey(
                        name: "FK_Reservations_Guests_Guest_id",
                        column: x => x.Guest_id,
                        principalTable: "Guests",
                        principalColumn: "Guest_id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Reservations_Rooms_Room_id",
                        column: x => x.Room_id,
                        principalTable: "Rooms",
                        principalColumn: "Room_id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Bills",
                columns: table => new
                {
                    Billing_No = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Transaction_type = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false),
                    Total_bill = table.Column<int>(type: "int", nullable: false),
                    Reservation_id = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Bills", x => x.Billing_No);
                    table.ForeignKey(
                        name: "FK_Bills_Reservations_Reservation_id",
                        column: x => x.Reservation_id,
                        principalTable: "Reservations",
                        principalColumn: "Reservation_id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Bills_Reservation_id",
                table: "Bills",
                column: "Reservation_id");

            migrationBuilder.CreateIndex(
                name: "IX_Reservations_Guest_id",
                table: "Reservations",
                column: "Guest_id");

            migrationBuilder.CreateIndex(
                name: "IX_Reservations_Room_id",
                table: "Reservations",
                column: "Room_id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Bills");

            migrationBuilder.DropTable(
                name: "Inventories");

            migrationBuilder.DropTable(
                name: "Reservations");

            migrationBuilder.DropTable(
                name: "Guests");

            migrationBuilder.DropTable(
                name: "Rooms");
        }
    }
}
